package rit.cs;

/**
 * file: IntExpression.java
 * This class is for evaluating and emitting integers
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */

public class IntExpression implements Expression {
    /**Single Integer of an expression**/
    private int value;

    /**
     * Initializing the integer of an expression
     * @param value: integer of an expression
     */
    public IntExpression(int value){
        this.value = value;
    }

    @Override
    public int evaluate(){
        return this.value;
    }

    @Override
    public String emit(){
        return String.valueOf(this.value);
    }
}
