package rit.cs;
/**
 * file: AddExpression.java
 * This class is for evaluating and emitting expressions dealing with addition
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */


public class AddExpression implements Expression{
    /** left side of the expression **/
    private Expression leftVal;
    /** right side of the expression **/
    private Expression rightVal;

    /**
     * Initalizing left and right sides of the expression
     * @param left: left side of the expression
     * @param right: right side of the expression
     */
    public AddExpression(Expression left, Expression right){
        this.leftVal = left;
        this.rightVal = right;
    }


    @Override
    public int evaluate(){
        return this.leftVal.evaluate()+this.rightVal.evaluate();
    }


    @Override
    public String emit(){
        return "(" + this.leftVal.emit() + " + " + this.rightVal.emit() + ")";
    }
}
