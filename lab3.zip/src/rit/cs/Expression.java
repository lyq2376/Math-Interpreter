package rit.cs;

/**
 * Interface will be used to run
 * evaluate and emit methods for all expressions possible
 * Evaluate method will be used to get the correct answer of the whole expression
 * through recursion from the parse method in Mint.Java
 * Emit method will be used to print out the correct and complete expression
 * through recursion from the parse method in Mint.Java
 */
public interface Expression {
    public int evaluate();
    public String emit();
}
