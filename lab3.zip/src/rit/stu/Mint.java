package rit.stu;
import rit.cs.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * file: Mint.java
 * This main class for evaluating and emitting expressions
 * language: Java
 * author: Lindy Quach
 * email: lyq2376@rit.edu
 * section: 1 (Group A)
 */
public class Mint{
    private ArrayList<String> tokens;
    private Scanner sc;
    public Mint(){
        this.tokens = new ArrayList<String>();
        this.sc = new Scanner(System.in);
    }

    /**
     * Initializing a Mint object to run prefix method
     * @param args: System argument
     */
    public static void main (String[]args){
        Mint mint = new Mint();
        mint.prefix();

    }

    /**
     * Getting input and printing output
     * All expressions are typed out in prefix form
     * Expressions will be split up into a native array
     * The array will turn into an ArrayList
     * ArrayList will go into the parse method
     * Output will be the emitted and evaluated form of the inputted
     * expression that comes from the parse method
     * Will keep going until input is quit
     * @rit.pre Mint object must be used to run this method
     */
    public void prefix(){
        System.out.println("Mint v1.0 :)");
        System.out.println("Welcome! Please enter an expression.");
        System.out.print("> ");
        String expression = this.sc.nextLine();
        while(!(expression.equals("quit"))){
            String[]Expression = expression.split("\\s++");
            for(int i = 0; i < Expression.length; ++i){
                this.tokens.add(Expression[i]);
            }
            Expression equation = parse(this.tokens);
            System.out.println("Emit: " + equation.emit());
            System.out.println("Evaluate: " + equation.evaluate());
            System.out.print("> ");
            expression = this.sc.nextLine();

        }
        System.out.println("Goodbye! :(");
        System.exit(0);
    }

    /**
     * Building a tree of expressions
     * Method has operations for each type of expression possible
     * Recursion will be used to build expressions within expressions
     * Each recursion call will deal with different integers and operations
     * @rit.pre An ArrayList will be used to help build the expressions
     * @param tokens: ArrayList that will be used to help build the expressions
     * @return Complete Expression that will be emitted and evaluated
     */
    public Expression parse(ArrayList<String> tokens){
        String save = tokens.remove(0);
        if(save.equals("+")){
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new AddExpression(left, right);
        }
        else if(save.equals("-")){
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new SubExpression(left, right);
        }
        else if(save.equals("/")){
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new DivExpression(left, right);
        }
        else if(save.equals("*")){
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new MulExpression(left, right);
        }
        else if(save.equals("%")){
            Expression left = parse(tokens);
            Expression right = parse(tokens);
            return new ModExpression(left, right);
        }
        else{
            return new IntExpression(Integer.parseInt(save));
        }
    }
}
